#include <18F4550.h>
#DEVICE ADC=10
#fuses HSPLL,MCLR,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN
#use delay(clock=48000000) //fisicamente lleva un Cristal de 20 mhz gracias al uso del PLL5
#define USB_HID_DEVICE FALSE //deshabilitamos el uso de las directivas HID
#define USB_EP1_TX_ENABLE USB_ENABLE_BULK //turn on EP1(EndPoint1) for IN bulk/interrupt transfers
#define USB_EP1_RX_ENABLE USB_ENABLE_BULK //turn on EP1(EndPoint1) for OUT bulk/interrupt transfers
#define USB_EP1_TX_SIZE 2 //size to allocate for the tx endpoint 1 buffer
#define USB_EP1_RX_SIZE 5 //size to allocate for the rx endpoint 1 buffer

#include <pic18_usb.h>      //Microchip PIC18Fxx5x Hardware layer for CCS's PIC USB driver
#include "usb_desc_scope.h" //para LABVIEW 
//#include <usb_desc_hid.h>    // HDI normal
#include <usb.c>            //handles usb setup tokens and get descriptor reports
//#define LCD_DATA_PORT getenv("SFR:PORTD") 
#include <LCD.C>
#include <math.h>
//Asignacion de variables
#define modo recibe[0]
#define param recibe[1]
#define set recibe[2]
#define point recibe[3]
#define ex recibe[4]
#define low envia[0]
#define hi envia[1]

//*****************declaramos variables globales*******************************
void temp (void);
void pota (void);
int8 recibe[4];
int8 envia[1];
int8 dato,dato1;
float temp1;
long setpoint;
float setpoint1;
//VARIABLES PID
int valor;
int control;
float a=11.1243,b=7.0006,c=62.1514; 
float rT,eT,pT,qT,yT,uT;
float pT_1=0.0;
float eT_1=0.0;
float max=255;
float min=0.0;
float salida;
//FIN DE VARIABLES PID

float pid();
//**********************PROGRAMA PRINCIPAL*************************************
void main(void)
{
Set_Tris_C(0b11111011);
set_tris_b(0x00); //Configuracion para el puerto D como salida
output_b(0x00); //Limpiamos el puerto D
setup_timer_0(RTCC_INTERNAL);
setup_timer_1(T1_DISABLED);
setup_timer_2(T2_DIV_BY_16,255,1);
setup_ccp1(ccp_pwm);
disable_interrupts(GLOBAL); //deshabilitamos todas las interrupciones


usb_init(); //inicializamos el USB
usb_task(); //habilita periferico usb e interrupciones
usb_wait_for_enumeration(); //esperamos hasta que el PicUSB sea configurado por el host

setup_port_a(ALL_ANALOG ); //habilitamos el puerto a para entrada analogica
setup_adc(ADC_CLOCK_INTERNAL); //Utilizamos el reloj interno

lcd_init();// inicializar lcd
while (TRUE)
{
if(usb_enumerated()) //Si el PicUSB está configurado
{
if (usb_kbhit(1)) //Si el endpoint de salida contiene datos del host
{
usb_get_packet(1, recibe, 5); //Cachamos el paquete de tama�o 2bytes del EP1 y almacenamos en recibe
delay_ms(10);
temp();
setpoint=make16(set,point);
setpoint1=(5.0/1023.0)*setpoint;
setpoint1=setpoint1*100.0;
lcd_gotoxy(1,1);
printf(lcd_putc,"\fset=%3.1f",setpoint1);
lcd_gotoxy(11,1);
printf(lcd_putc,"t=%3.1f",temp1);
lcd_gotoxy(1,2);
printf(lcd_putc,"con=%3u",control);
//lcd_gotoxy(8,2);
//printf(lcd_putc,"low=%3u",set);

usb_put_packet(1,envia,2,USB_DTS_TOGGLE); //enviamos el paquete de tamaño 1byte del EP1 al PC
//********************************************************************************************
if(temp1<=setpoint1){
   output_high(PIN_B2);
   output_low(PIN_B0);
   output_low(PIN_B1);
   }
 
  if(temp1>=setpoint1){
   output_low(PIN_B2);
   output_high(PIN_B0);
   output_high(PIN_B1);
   }
     
   if(temp1>(setpoint1+3)){
   output_high(PIN_B3);
   
   }
   else{
   output_low(PIN_B3);
   }
   
   
   if((temp1<=(setpoint1+1))&&(temp1>=(setpoint1-1))){
   output_high(pin_b4);
   }
   else{
   output_low(pin_b4);
   }


//********************************************************************************************
rT=setpoint1;
yT=temp1;

eT=abs(rT-yT);
pT=b*eT+pT_1;
qT=c*(eT-eT_1);
uT=pT+a*eT+qT;
salida=uT;
if(uT>max){
uT=max;}
else{
if(uT<min){
uT=min;
}
}
control=uT;
set_pwm1_duty(control);

pT_1=pT=0;
eT_1=eT=0;
delay_ms(50);



//********************************************************************************************
}

}

}
}
// ***************FUNCIONES**************************************************
void temp (void) // valor del lm35
{
 int16 value;
   int hi_value;
   int low_value;
value=0x00;
set_adc_channel(0); // Tomamos datos del canal 5 (Pin4 RA2/AN2)
delay_ms(4); // Hacemos un retardo de 4 ms
value=read_adc(); // Leemos el dato
delay_ms(10); // Hacemos un retardo de 10 ms
      low_value=value;
      hi_value=value>>8;
      low=low_value;
      hi=hi_value;
    temp1=(5.0/1023.0)*value;
 temp1=temp1*100.0;    
 
}

void pota (void) //valor del potenciometro
{
set_adc_channel(1); // Tomamos datos del canal 5 (Pin4 RA2/AN2)
delay_ms(4); // Hacemos un retardo de 4 ms
dato1=read_adc(); // Leemos el dato
delay_ms(10); // Hacemos un retardo de 10 ms
//potenciometro=dato1; // El dato leido lo almacenamos en potenciometro
}

float pid(){
temp();
rT=setpoint1;
yT=temp1;

eT=abs(rT-yT);
pT=b*eT+pT_1;
qT=c*(eT-eT_1);
uT=pT+a*eT+qT;
if(uT>max){
uT=max;}
else{
if(uT<max){
uT=min;
}
}
control=uT;
set_pwm1_duty(control);

pT_1=pT;
eT_1=eT;
delay_ms(100);
return control;
}
