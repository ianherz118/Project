import cv2
import numpy as np
import os 
import random
import pandas as pd
import sys
from tkinter import messagebox as MessageBox

path='C:/Users/10 64/Pictures/Imagenes proyecto'

orb=cv2.ORB_create(nfeatures =1000)
images=[]
classNames=[]
count=0
listCard=[]
listRandom=[]
listRandom2=[]
countplayer1=0
countplayer2=0
countwin1=0
countwin2=0
# propose of cards player 1 y player 2

myList=os.listdir(path)

print('Total classes Detected',len(myList))
for cl in myList:
    imgCur=cv2.imread(f'{path}/{cl}',0)
    images.append(imgCur)
    classNames.append(os.path.splitext(cl)[0])
# print(classNames)

def findDes(images):
   desList=[]
   for img in images:
       kp,des=orb.detectAndCompute(img,None)
       desList.append(des)
   return desList

def findID(img,desList,thres=15):
    kp2,des2=orb.detectAndCompute(img,None)
    bf=cv2.BFMatcher()
    matchList=[]
    finalVal=-1
    try:
        for des in desList:
            matches=bf.knnMatch(des,des2,k=2)
            good=[]
            for m,n in matches:
                if m.distance <0.75*n.distance:
                    good.append([m])
            matchList.append(len(good))
    except:
        pass
    # print(matchList)
    if len(matchList)!=0:
        if max(matchList)>thres:
            finalVal=matchList.index(max(matchList))
    return finalVal

desList=findDes(images)
# print(len(desList))
print('____________________________________________________')


print('The lotery cards are:',classNames)

print('####################################################')

print('Deck of cards player 1:')
print('____________________________________________________')
# for i in range(16):
#     nuRandom=random.randrange(0, 42)
#     listRandom.append(classNames[nuRandom])
# print(listRandom)  
listnumber=[random.randrange(43)] 
n=0 
while n<15:  
 x=random.randrange(43) 
 norepe=True 
 while norepe:  
  for j in range(len(listnumber)):  
   if x==listnumber[j]:  
    norepe=False 
  if norepe:  
   listnumber.append(x)  
   listRandom.append(classNames[x])
   n+=1  
print(listRandom) 
    
print('####################################################')

print('Deck of cards player 2:')
print('____________________________________________________')

# for i in range(16):
#     nuRandom2=random.randrange(0, 42)
#     listRandom2.append(classNames[nuRandom2])
# print(listRandom2)  

print('####################################################')
n=0 
while n<15:  
 x=random.randrange(43) 
 norepe=True 
 while norepe:  
  for j in range(len(listnumber)):  
   if x==listnumber[j]:  
    norepe=False 
  if norepe:  
   listnumber.append(x)  
   listRandom2.append(classNames[x])
   n+=1  
print(listRandom2)  
print('####################################################')

cap=cv2.VideoCapture(0)

while True:
    
    #Si no desea usar web cam cambie insertando una imagen para identificar
    
    sucess,img2=cap.read()
    imgOriginal=img2.copy()
    img2=cv2.cvtColor(img2,cv2.COLOR_BGR2GRAY)
    
    id=findID(img2,desList)
    
    if id!=-1:
        cv2.putText(imgOriginal,classNames[id],(0,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),1)
        if classNames[id] in listCard:
            print('Saved')
        else:
            listCard.append(classNames[id])
            if classNames[id] in listRandom:
                countplayer1=countplayer1+1
                win1 = listRandom.index(classNames[id])
                if win1==0 or win1==5 or win1==10 or win1==15:
                    countwin1=countwin1+1
             
            if classNames[id] in listRandom2:
                countplayer2=countplayer2+1
                win2 = listRandom2.index(classNames[id])
                if win2==0 or win2==5 or win2==10 or win2==15:
                    countwin2=countwin2+1
            
        print(classNames[id])
        count=count+1
    
    cv2.imshow('img2',imgOriginal)
    
    #condicion para ganar diagonal en mazo 1 o mazo 2
    
    if (countwin1==3 or countwin2==3) and (count<40):
        if countwin1==3:
            MessageBox.showwarning("Alerta", "Winner player 1")
            sys.exit()

        else:
            MessageBox.showwarning("Alerta", "Winner player 2")            
            sys.exit()
            
    #condicionante de lectura de mazos 
            
    if count>150 or countplayer1==15 or countplayer2==15:
        print(listCard)
        print('____________________________________')
        print('Cards founds player 1:',countplayer1)
        print('Cards founds player 2:',countplayer2) 
        
        if countplayer1==15:
            MessageBox.showwarning("Alerta", "Winner player 1")
        else:
            MessageBox.showwarning("Alerta", "Winner player 2")            
        sys.exit()
        
    cv2.waitKey(1)


