import cv2
import numpy as cv
import os  
ima1=cv2.imread('luna.jpg',0)
ima2=cv2.imread('tluna.jpg',0)
orb=cv2.ORB_create(nfeatures =1000)
#generamos descriptores para las imagenes
kp1,des1=orb.detectAndCompute(ima1,None)
kp2,des2=orb.detectAndCompute(ima2,None)
bf=cv2.BFMatcher()
matches=bf.knnMatch(des1,des2,k=2)
perfil1=[]
for m,n in matches:
    if m.distance <0.75*n.distance:
        perfil1.append([m])
print(len(perfil1))
img3=cv2.drawMatchesKnn(ima1,kp1,ima2,kp2,perfil1,None,flags=2)
# ima1kp1=cv2.drawKeypoints(ima1,kp1,None)
# ima1kp2=cv2.drawKeypoints(ima2,kp1,None)
cv2.imshow('ima1',ima1)
cv2.imshow('ima2',ima2)
cv2.imshow('ima3',img3)

print(des1[0])
cv2.waitKey(0)



